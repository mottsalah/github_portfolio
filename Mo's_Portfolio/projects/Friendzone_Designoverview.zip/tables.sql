-- Table for User Entity
CREATE TABLE Users (
    User_ID INT PRIMARY KEY AUTO_INCREMENT,
    EmailAddress VARCHAR(100) NOT NULL UNIQUE,
    PasswordHash VARCHAR(100) NOT NULL,
    FirstName VARCHAR(50) NOT NULL,
    LastName VARCHAR(50) NOT NULL,
    Biography TEXT,
    MobilePhoneNumber VARCHAR(20)
);

-- Table for Post Entity
CREATE TABLE Post (
    Post_ID INT PRIMARY KEY AUTO_INCREMENT,
    User_ID INT,
    Content VARCHAR(280) NOT NULL,
    Date_Posted DATETIME NOT NULL,
    FOREIGN KEY (User_ID) REFERENCES Users(User_ID) ON DELETE CASCADE
);

-- Table for Comment Entity
CREATE TABLE Comment (
    Comment_ID INT PRIMARY KEY AUTO_INCREMENT,
    User_ID INT,
    Post_ID INT,
    Content VARCHAR(280) NOT NULL,
    Date_Posted DATETIME NOT NULL,
    FOREIGN KEY (User_ID) REFERENCES Users(User_ID) ON DELETE CASCADE,
    FOREIGN KEY (Post_ID) REFERENCES Post(Post_ID) ON DELETE CASCADE
);